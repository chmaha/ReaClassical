-- Load ReaImGui
local imgui = reaper.ImGui_CreateContext("Crossfade Editor")

-- Helper function to retrieve fade data
function GetFadeInfo(item)
    local fadein_len = reaper.GetMediaItemInfo_Value(item, "D_FADEINLEN")
    local fadeout_len = reaper.GetMediaItemInfo_Value(item, "D_FADEOUTLEN")
    local item_len = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
    
    return fadein_len, fadeout_len, item_len
end

-- Function to get peaks from a media item
function GetItemPeaks(item, samples_per_pixel, peakrate)
    local take = reaper.GetActiveTake(item)
    if take == nil then return nil end

    local source = reaper.GetMediaItemTake_Source(take)
    local num_channels = reaper.GetMediaSourceNumChannels(source)
    local length = reaper.GetMediaItemInfo_Value(item, "D_LENGTH")
    local num_samples = math.floor(length * reaper.GetMediaSourceSampleRate(source))
    
    -- Calculate the total number of peaks
    local num_peaks = math.floor((num_samples / samples_per_pixel) * num_channels * 2)

    -- Ensure the number passed to new_array is a valid integer
    num_peaks = math.max(num_peaks, 1)  -- Ensure at least 1 peak is requested to avoid errors
    
    -- Get peaks (will return peak values, negative and positive)
    local peaks = reaper.new_array(num_peaks)
    local ret = reaper.PCM_Source_GetPeaks(source, peakrate, 0, num_samples, samples_per_pixel, num_channels, peaks)
    
    -- Check if peaks are retrieved successfully
    if ret == 0 then
        return nil, nil, nil
    end
    
    return peaks.table(), num_channels, num_samples
end

-- Function to draw waveform lane, including fades and grayscaled post-fade regions
function DrawWaveform(peaks, num_channels, num_samples, scale_x, scale_y, fadein_len, fadeout_len, item_len)
    local draw_list = reaper.ImGui_GetWindowDrawList(imgui)
    local window_pos_x, window_pos_y = reaper.ImGui_GetWindowPos(imgui)
    local width, height = reaper.ImGui_GetContentRegionAvail(imgui)
    
    local half_height = height / 2
    
    local fadein_samples = math.floor(fadein_len * num_samples / item_len)
    local fadeout_start = num_samples - math.floor(fadeout_len * num_samples / item_len)
    
    for i = 0, num_samples - 1 do
        local x = window_pos_x + i * scale_x
        
        for ch = 0, num_channels - 1 do
            -- Ensure peaks are valid before accessing
            local peak_min = peaks[i * num_channels * 2 + ch * 2 + 1]
            local peak_max = peaks[i * num_channels * 2 + ch * 2 + 2]

            if peak_min and peak_max then  -- Check for nil values
                local y_min = window_pos_y + half_height + peak_min * scale_y
                local y_max = window_pos_y + half_height + peak_max * scale_y

                -- Draw normal waveform before fades
                if i <= fadein_samples or i >= fadeout_start then
                    -- Draw in normal color
                    reaper.ImGui_DrawList_AddLine(draw_list, x, y_min, x, y_max, 0xFFFFFFFF)
                else
                    -- Draw post-fade waveform in grayscale
                    reaper.ImGui_DrawList_AddLine(draw_list, x, y_min, x, y_max, 0x80808080)
                end
            end
        end
        
        -- Draw fade shapes (e.g., linear fade in/out shapes for simplicity)
        if i <= fadein_samples then
            local fadein_factor = i / fadein_samples
            reaper.ImGui_DrawList_AddLine(draw_list, x, window_pos_y + half_height * (1 - fadein_factor), x, window_pos_y + half_height * (1 + fadein_factor), 0xFF00FF00)
        end
        if i >= fadeout_start then
            local fadeout_factor = (num_samples - i) / (num_samples - fadeout_start)
            reaper.ImGui_DrawList_AddLine(draw_list, x, window_pos_y + half_height * (1 - fadeout_factor), x, window_pos_y + half_height * (1 + fadeout_factor), 0xFF00FF00)
        end
    end
end

-- Main function to show the crossfade editor window
function ShowCrossfadeEditor(open)
    if reaper.ImGui_Begin(imgui, "Crossfade Editor", open) then
        local num_items = reaper.CountSelectedMediaItems(0)
        if num_items < 2 then
            reaper.ImGui_Text(imgui, "Please select two media items to display waveforms.")
        else
            -- Get the selected media items
            local item1 = reaper.GetSelectedMediaItem(0, 0)
            local item2 = reaper.GetSelectedMediaItem(0, 1)
            
            -- Set drawing scales
            local samples_per_pixel = 128
            local scale_x = 1.0 -- Horizontal scale (pixels per sample)
            local scale_y = 50.0 -- Vertical scale (amplitude scale)
            
            -- Retrieve peaks and fade data for both items
            local peaks1, num_channels1, num_samples1 = GetItemPeaks(item1, samples_per_pixel, 44100)
            local fadein_len1, fadeout_len1, item_len1 = GetFadeInfo(item1)
            
            local peaks2, num_channels2, num_samples2 = GetItemPeaks(item2, samples_per_pixel, 44100)
            local fadein_len2, fadeout_len2, item_len2 = GetFadeInfo(item2)
            
            -- Draw lane 1 (Item 1)
            reaper.ImGui_Text(imgui, "Item 1 Waveform")
            if peaks1 then 
                DrawWaveform(peaks1, num_channels1, num_samples1, scale_x, scale_y, fadein_len1, fadeout_len1, item_len1) 
            end
            
            reaper.ImGui_Spacing(imgui)
            reaper.ImGui_Separator(imgui)
            reaper.ImGui_Spacing(imgui)
            
            -- Draw lane 2 (Item 2)
            reaper.ImGui_Text(imgui, "Item 2 Waveform")
            if peaks2 then 
                DrawWaveform(peaks2, num_channels2, num_samples2, scale_x, scale_y, fadein_len2, fadeout_len2, item_len2) 
            end
        end
        
        reaper.ImGui_End(imgui)
    end
end

-- Main loop
function Main()
    local open = true
    ShowCrossfadeEditor(open)
    
    -- Keep the window running until closed
    if open then
        reaper.defer(Main)  -- Continue running the script
    else
        reaper.ImGui_DestroyContext(imgui)
    end
end

-- Run the script
Main()

