-- Start script: REAPER Update Utility (check for new versions)
local update_utility_cmd = '_RS852f0872789b997921f7f9d40e6f997553bd5147'
-- reaper.Main_OnCommand(reaper.NamedCommandLookup(update_utility_cmd), 0)

