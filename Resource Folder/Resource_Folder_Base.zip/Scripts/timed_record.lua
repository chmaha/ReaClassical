-- Helper to parse time into a timestamp (today's date with time)
local function parse_time(input)
    local pattern = "(%d+):(%d+)"
    local hour, min = input:match(pattern)
    if hour and min then
        local now = os.date("*t")
        now.hour = tonumber(hour)
        now.min = tonumber(min)
        now.sec = 0 -- Default seconds to 0
        return os.time(now)
    else
        return nil, "Invalid time format. Use HH:MM."
    end
end

-- Prompt user for start time, end time or recording duration
local retval, user_input = reaper.GetUserInputs("Schedule Recording", 3,
    "Start Time (HH:MM),End Time (optional, HH:MM),Duration (optional, HH:MM)", "")
if not retval then return end

local start_time_str, end_time_str, duration_str = user_input:match("([^,]*),([^,]*),([^,]*)")
if not start_time_str or start_time_str == "" then
    reaper.ShowMessageBox("Start time is required!", "Error", 0)
    return
end

local start_time, err = parse_time(start_time_str)
if not start_time then
    reaper.ShowMessageBox(err, "Error", 0)
    return
end

-- Handle end time or recording duration
local end_time = nil
if end_time_str and end_time_str ~= "" then
    end_time, err = parse_time(end_time_str)
    if not end_time then
        reaper.ShowMessageBox(err, "Error", 0)
        return
    end
elseif duration_str and duration_str ~= "" then
    duration, err = parse_time(duration_str)
    if not duration then
        reaper.ShowMessageBox(err, "Error", 0)
        return
    end
    end_time = start_time + duration
end

-- Confirm schedule
reaper.ShowMessageBox("Recording scheduled to start at: " .. os.date("%H:%M", start_time) ..
    (end_time and ("\nAnd stop at: " .. os.date("%H:%M", end_time)) or ""), "Schedule Confirmed", 0)

-- Track the last check time
local last_check_time = os.time()

-- Function to check time and control recording
local function check_time()
    local current_time = os.time()
    local response
    -- Only execute if 1 second has elapsed
    if current_time - last_check_time >= 1 then
        last_check_time = current_time  -- Update last_check_time to the current time

        -- Start recording if current time matches or exceeds start time
        if current_time >= start_time and reaper.GetPlayState() ~= 5 then
            reaper.Main_OnCommand(1013, 0) -- Record command
        end
        
        -- Stop recording if current time matches or exceeds end time
        if end_time and current_time >= end_time and reaper.GetPlayState() == 5 then
            reaper.Main_OnCommand(1016, 0) -- Stop command
            return -- End the script
        end
    end

    -- Defer the next call to this function
    reaper.defer(check_time)
end

-- Start checking time
check_time()

