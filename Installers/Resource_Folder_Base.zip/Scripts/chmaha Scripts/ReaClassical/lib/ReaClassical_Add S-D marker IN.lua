--[[
@noindex

This file is a part of "ReaClassical" package.
See "ReaClassical.lua" for more information.

Copyright (C) 2022–2026 chmaha

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
]]

-- luacheck: ignore 113

for key in pairs(reaper) do _G[key] = reaper[key] end

local _gm_path = debug.getinfo(1, "S").source:match("@(.+[\\/])")
package.path = package.path .. ";" .. _gm_path .. "?.lua;" .. _gm_path .. "lib/?.lua;"
local gui_mode = require("ReaClassical_GuiMode")

local script_path = debug.getinfo(1, "S").source:match("@(.+[\\/])")
package.path = package.path .. ";" .. script_path .. "?.lua;" .. script_path .. "lib/?.lua;"
local say = require("ReaClassical_Announce")
local humanize_timestr = require("ReaClassical_Time_Naming")
local humanize_folder_phrase = require("ReaClassical_Folder_Naming")
local enum_project_markers = require("ReaClassical_Marker_Enum")

local main, get_color_table, add_destination_in, add_source_in
local folder_check, get_track_number, get_track_prefix
local move_destination_folder, get_tracks_per_group, calculate_destination_info
local convert_pair_to_take_marker, find_source_marker
local project_pos_to_source_pos, get_item_at_position
local set_take_marker_with_length

local _, opened_string = GetProjExtState(0, "ReaClassical", "toolbaropened")

if opened_string ~= "y" then
    if not gui_mode.accessible() then
        local editing_toolbar = reaper.NamedCommandLookup("_RSdcbfd5e17e15e31f892e3fefdb1969b81d22b6df")
        Main_OnCommand(editing_toolbar, 0)
    end
    SetProjExtState(0, "ReaClassical", "toolbaropened", "y")
end

function main()
    PreventUIRefresh(1)
    local _, workflow = GetProjExtState(0, "ReaClassical", "Workflow")
    if workflow == "" then
        local modifier = "Ctrl"
        local system = GetOS()
        if string.find(system, "^OSX") or string.find(system, "^macOS") then
            modifier = "Cmd"
        end
        MB("Please create a ReaClassical project via " .. modifier
            .. "+N to use this function.", "ReaClassical Error", 0)
        PreventUIRefresh(-1)
        return
    end

    local _, input = GetProjExtState(0, "ReaClassical", "Preferences")
    local sdmousehover = 0
    local moveable_dest = 0
    local to_takemarkers = 0
    if input ~= "" then
        local table = {}
        for entry in input:gmatch('([^,]+)') do table[#table + 1] = entry end
        if table[8] then sdmousehover = tonumber(table[8]) or 0 end
        if table[12] then moveable_dest = tonumber(table[12]) or 0 end
        if table[15] then to_takemarkers = tonumber(table[15]) or 0 end
    end

    local selected_track = GetSelectedTrack(0, 0)

    local cur_pos, track
    if sdmousehover == 1 then
        cur_pos = BR_PositionAtMouseCursor(false)
        local screen_x, screen_y = GetMousePosition()
        track = GetTrackFromPoint(screen_x, screen_y)
    else
        cur_pos = (GetPlayState() == 0) and GetCursorPosition() or GetPlayPosition()
    end

    if cur_pos ~= -1 then
        local is_destination = (workflow == "Horizontal")
        if not is_destination then
            local resolved_track = track or selected_track
            is_destination = (get_track_prefix(resolved_track) == "D")
        end

        if is_destination then
            add_destination_in(cur_pos, workflow, selected_track)
        else
            add_source_in(cur_pos, workflow, track, selected_track, moveable_dest, to_takemarkers)
        end
    end
    PreventUIRefresh(-1)
end

function add_destination_in(cur_pos, workflow, selected_track)
    local i = 0
    while true do
        local project, _ = EnumProjects(i)
        if project == nil then
            break
        else
            DeleteProjectMarker(project, 996, false)
        end
        i = i + 1
    end

    local track_prefix = "D"
    local track_number = 1

    if selected_track then SetOnlyTrackSelected(selected_track) end

    local colors = get_color_table()

    local marker_color = (workflow == "Horizontal") and colors.dest_marker or colors.dest_items
    local marker_label = (workflow == "Horizontal") and "DEST-IN" or (track_prefix .. ":DEST-IN")
    AddProjectMarker2(0, false, cur_pos, 0, marker_label, 996, marker_color)
    SetProjExtState(0, "ReaClassical", "DestInTrackNum", tostring(track_number))
    local folder_phrase = humanize_folder_phrase(track_prefix)
    say("Added destination in @ " .. humanize_timestr(format_timestr_pos(cur_pos, "", -1))
        .. (folder_phrase ~= "" and (" in " .. folder_phrase) or ""))
end

function add_source_in(cur_pos, workflow, track, selected_track, moveable_dest, to_takemarkers)
    local dest_track_num = calculate_destination_info()

    local track_number = math.floor(get_track_number(track))
    local track_prefix = get_track_prefix(track)

    if to_takemarkers == 1 then
        convert_pair_to_take_marker(998, "SOURCE-IN", cur_pos, track_number)
    else
        local i = 0
        while true do
            local project, _ = EnumProjects(i)
            if project == nil then
                break
            else
                DeleteProjectMarker(project, 998, false)
            end
            i = i + 1
        end
    end

    if moveable_dest == 1 then
        move_destination_folder(track_number)
    end

    if dest_track_num and dest_track_num > track_number then
        track_number = track_number + get_tracks_per_group()
    end

    if selected_track then SetOnlyTrackSelected(selected_track) end

    local color_track = track or selected_track
    local colors = get_color_table()
    local marker_color
    if workflow == "Horizontal" then
        marker_color = colors.source_marker
    else
        marker_color = color_track and GetTrackColor(color_track) or colors.source_marker
    end

    local marker_label = (workflow == "Horizontal") and "SOURCE-IN" or (track_prefix .. ":SOURCE-IN")
    AddProjectMarker2(0, false, cur_pos, 0, marker_label, 998, marker_color)
    SetProjExtState(0, "ReaClassical", "SourceInTrackNum", tostring(track_number))
    local folder_phrase = humanize_folder_phrase(track_prefix)
    say("Added source in @ " .. humanize_timestr(format_timestr_pos(cur_pos, "", -1))
        .. (folder_phrase ~= "" and (" in " .. folder_phrase) or ""))
end

function convert_pair_to_take_marker(marker_id, marker_type, new_pos, new_track_number)
    local black_color = ColorToNative(0, 0, 0) | 0x1000000

    local proj = EnumProjects(-1)
    if not proj then return end

    local ext_key = (marker_type == "SOURCE-IN") and "SourceInTrackNum" or "SourceOutTrackNum"
    local _, stored = GetProjExtState(0, "ReaClassical", ext_key)
    local marker_track_num = tonumber(stored)

    local num_markers = GetNumRegionsOrMarkers(proj)
    local marker_pos = nil

    for i = 0, num_markers - 1 do
        local _, isrgn, pos, _, raw_label, markrgnindexnumber = enum_project_markers(proj, i)
        if not isrgn and markrgnindexnumber == marker_id then
            local label = raw_label:match(":(.+)$") or raw_label
            if label == marker_type then
                marker_pos = pos
            end
            break
        end
    end

    if not marker_pos or not marker_track_num then
        local i = 0
        while true do
            local project, _ = EnumProjects(i)
            if project == nil then break end
            DeleteProjectMarker(project, marker_id, false)
            i = i + 1
        end
        return
    end

    local other_id = (marker_type == "SOURCE-IN") and 999 or 998
    local other_type = (marker_type == "SOURCE-IN") and "SOURCE-OUT" or "SOURCE-IN"
    local other_ext_key = (marker_type == "SOURCE-IN") and "SourceOutTrackNum" or "SourceInTrackNum"
    local other_pos = find_source_marker(proj, other_id, other_type)
    local _, other_stored = GetProjExtState(0, "ReaClassical", other_ext_key)
    local other_track_num = tonumber(other_stored)

    local is_pair = other_pos and other_track_num and
        marker_track_num and other_track_num == marker_track_num

    if not is_pair then
        local i = 0
        while true do
            local project, _ = EnumProjects(i)
            if project == nil then break end
            DeleteProjectMarker(project, marker_id, false)
            i = i + 1
        end
        return
    end

    local in_pos, out_pos
    if marker_type == "SOURCE-IN" then
        in_pos = marker_pos
        out_pos = other_pos
    else
        in_pos = other_pos
        out_pos = marker_pos
    end

    if in_pos >= out_pos then
        local i = 0
        while true do
            local project, _ = EnumProjects(i)
            if project == nil then break end
            DeleteProjectMarker(project, marker_id, false)
            i = i + 1
        end
        return
    end

    local item_in, take_in = get_item_at_position(in_pos, marker_track_num)
    local item_out, _ = get_item_at_position(out_pos, marker_track_num)

    if not item_in or not item_out or item_in ~= item_out then
        local i = 0
        while true do
            local project, _ = EnumProjects(i)
            if project == nil then break end
            DeleteProjectMarker(project, marker_id, false)
            i = i + 1
        end
        return
    end

    local new_item, _ = get_item_at_position(new_pos, new_track_number)
    if new_item and new_item == item_in then
        local i = 0
        while true do
            local project, _ = EnumProjects(i)
            if project == nil then break end
            DeleteProjectMarker(project, marker_id, false)
            i = i + 1
        end
        return
    end

    local _, existing_chunk = GetItemStateChunk(item_in, "", false)
    local has_saud = existing_chunk and
        existing_chunk:find("\n%s*TKM%s+%-?[%d%.e%+%-]+%s+S%-AUD%s+") ~= nil

    if has_saud then
        local stripped = existing_chunk:gsub("\n%s*TKM%s+%-?[%d%.e%+%-]+%s+S%-AUD%s+[^\n]*", "")
        SetItemStateChunk(item_in, stripped, false)
    end

    if take_in then
        local src_in = project_pos_to_source_pos(take_in, item_in, in_pos)
        local src_out = project_pos_to_source_pos(take_in, item_in, out_pos)
        if src_in and src_out then
            set_take_marker_with_length(item_in, src_in, src_out, "S-AUD", black_color)
        end
    end

    local i = 0
    while true do
        local project, _ = EnumProjects(i)
        if project == nil then break end
        DeleteProjectMarker(project, 998, false)
        DeleteProjectMarker(project, 999, false)
        i = i + 1
    end
end

function set_take_marker_with_length(item, src_start, src_end, name, color)
    local _, chunk = GetItemStateChunk(item, "", false)
    if not chunk or chunk == "" then return end

    local length = src_end - src_start
    local marker_line = string.format(
        '    TKM %.14g %s %d %.14g',
        src_start, name, color, length
    )

    local insert_pos = chunk:find("\n>%s*$")
    if insert_pos then
        chunk = chunk:sub(1, insert_pos - 1) .. "\n" .. marker_line .. chunk:sub(insert_pos)
    else
        chunk = chunk:gsub("(>)%s*$", marker_line .. "\n>")
    end

    SetItemStateChunk(item, chunk, false)
end

function find_source_marker(proj, marker_id, marker_type)
    local num_markers = GetNumRegionsOrMarkers(proj)

    for i = 0, num_markers - 1 do
        local _, isrgn, pos, _, raw_label, markrgnindexnumber = enum_project_markers(proj, i)
        if not isrgn and markrgnindexnumber == marker_id then
            local label = raw_label:match(":(.+)$") or raw_label
            if label == marker_type then
                return pos
            end
        end
    end

    return nil
end

function get_item_at_position(proj_pos, track_number)
    local tr = GetTrack(0, track_number - 1)
    if not tr then return nil, nil end

    local tracks_to_check = { tr }
    if GetMediaTrackInfo_Value(tr, "I_FOLDERDEPTH") == 1 then
        local depth = 1
        local idx = track_number
        while depth > 0 and idx < CountTracks(0) do
            local child = GetTrack(0, idx)
            if child then
                tracks_to_check[#tracks_to_check + 1] = child
                depth = depth + GetMediaTrackInfo_Value(child, "I_FOLDERDEPTH")
            end
            idx = idx + 1
        end
    end

    for _, check_tr in ipairs(tracks_to_check) do
        local num_items = CountTrackMediaItems(check_tr)
        for j = 0, num_items - 1 do
            local item = GetTrackMediaItem(check_tr, j)
            if item then
                local item_pos = GetMediaItemInfo_Value(item, "D_POSITION")
                local item_len = GetMediaItemInfo_Value(item, "D_LENGTH")
                if proj_pos >= item_pos and proj_pos <= item_pos + item_len then
                    local take = GetActiveTake(item)
                    if take then return item, take end
                end
            end
        end
    end

    return nil, nil
end

function project_pos_to_source_pos(take, item, proj_pos)
    if not take or not item then return nil end
    local item_pos = GetMediaItemInfo_Value(item, "D_POSITION")
    local take_offset = GetMediaItemTakeInfo_Value(take, "D_STARTOFFS")
    local take_rate = GetMediaItemTakeInfo_Value(take, "D_PLAYRATE")
    return take_offset + (proj_pos - item_pos) * take_rate
end

function folder_check()
    local folders = 0
    local total_tracks = CountTracks(0)
    for i = 0, total_tracks - 1, 1 do
        local track = GetTrack(0, i)
        if GetMediaTrackInfo_Value(track, "I_FOLDERDEPTH") == 1 then
            folders = folders + 1
        end
    end
    return folders
end

function get_track_number(track)
    if not track then track = GetSelectedTrack(0, 0) end
    if folder_check() == 0 or track == nil then
        return 1
    elseif GetMediaTrackInfo_Value(track, "I_FOLDERDEPTH") == 1 then
        return GetMediaTrackInfo_Value(track, "IP_TRACKNUMBER")
    else
        local folder = GetParentTrack(track)
        return GetMediaTrackInfo_Value(folder, "IP_TRACKNUMBER")
    end
end

function get_track_prefix(track)
    if not track then track = GetSelectedTrack(0, 0) end
    if folder_check() == 0 or track == nil then
        return "1"
    end
    local folder
    if GetMediaTrackInfo_Value(track, "I_FOLDERDEPTH") == 1 then
        folder = track
    else
        folder = GetParentTrack(track)
    end
    if folder then
        local _, name = GetTrackName(folder)
        local prefix = name:match("^(.-):")
        if prefix then return prefix end
    end
    return tostring(math.floor(GetMediaTrackInfo_Value(folder or track, "IP_TRACKNUMBER")))
end

function move_destination_folder(track_number)
    local destination_folder = nil
    local track_count = CountTracks(0)
    for i = 0, track_count - 1 do
        local tr = GetTrack(0, i)
        if tr then
            local _, track_name = GetSetMediaTrackInfo_String(tr, "P_NAME", "", false)
            if track_name:find("^D:") and GetMediaTrackInfo_Value(tr, "I_FOLDERDEPTH") == 1 then
                destination_folder = tr
                break
            end
        end
    end
    if not destination_folder then return end
    local target_track = GetTrack(0, track_number - 1)
    if not target_track then return end
    local destination_index = GetMediaTrackInfo_Value(destination_folder, "IP_TRACKNUMBER") - 1
    local target_index = track_number - 1
    if destination_index ~= target_index then
        SetOnlyTrackSelected(destination_folder)
        ReorderSelectedTracks(target_index, 0)
    end
end

function get_tracks_per_group()
    local track_count = CountTracks(0)
    if track_count == 0 then return 0 end
    local tracks_per_group = 1
    local first_track = GetTrack(0, 0)
    if not first_track or GetMediaTrackInfo_Value(first_track, "I_FOLDERDEPTH") ~= 1 then
        return 0
    end
    for i = 1, track_count - 1 do
        local tr = GetTrack(0, i)
        if tr then
            if GetMediaTrackInfo_Value(tr, "I_FOLDERDEPTH") == 1 then break end
            tracks_per_group = tracks_per_group + 1
        end
    end
    return tracks_per_group
end

function calculate_destination_info()
    local track_count = CountTracks(0)
    local destination_folder = GetTrack(0, 0)
    for i = 0, track_count - 1 do
        local tr = GetTrack(0, i)
        if tr then
            local _, track_name = GetSetMediaTrackInfo_String(tr, "P_NAME", "", false)
            if track_name:find("^D:") and GetMediaTrackInfo_Value(tr, "I_FOLDERDEPTH") == 1 then
                destination_folder = tr
                break
            end
        end
    end
    return GetMediaTrackInfo_Value(destination_folder, "IP_TRACKNUMBER")
end

function get_color_table()
    return require("ReaClassical_Colors_Table")
end

main()
