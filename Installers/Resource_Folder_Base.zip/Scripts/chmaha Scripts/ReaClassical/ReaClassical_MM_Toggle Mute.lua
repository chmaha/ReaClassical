--[[
@noindex

This file is a part of "ReaClassical" package.
See "ReaClassical.lua" for more information.

Copyright (C) 2022–2026 chmaha

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
]]

-- luacheck: ignore 113

for key in pairs(reaper) do _G[key] = reaper[key] end

local script_path = debug.getinfo(1, "S").source:match("@(.+[\\/])")
package.path = package.path .. ";" .. script_path .. "?.lua;" .. script_path .. "lib/?.lua;"
local say = require("ReaClassical_Announce")
local mm  = require("ReaClassical_MM_Utils")
local groups = require("ReaClassical_MM_Groups")

local track = mm.get_current_target()
if not track then
    say("No special tracks found")
    return
end

local targets, grouped, group_name = groups.get_action_targets(track, "mute")
local muted = GetMediaTrackInfo_Value(track, "B_MUTE") > 0
local new_state = muted and 0 or 1
for _, t in ipairs(targets) do
    SetMediaTrackInfo_Value(t, "B_MUTE", new_state)
end
say((muted and "Mute off" or "Mute on") .. (grouped and (", " .. group_name .. " group") or ""))
