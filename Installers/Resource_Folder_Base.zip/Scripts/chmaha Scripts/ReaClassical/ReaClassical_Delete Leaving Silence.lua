--[[
@noindex

This file is a part of "ReaClassical" package.
See "ReaClassical.lua" for more information.

Copyright (C) 2022–2026 chmaha

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
]]

-- luacheck: ignore 113

for key in pairs(reaper) do _G[key] = reaper[key] end

local main, source_markers, select_matching_folder
local adaptive_delete, count_selected_media_items, get_selected_media_item_at
local nudge_xfades_at_source_boundaries, get_folder_items_at_midpoint
local select_midpoint_peers, find_folder_by_prefix

---------------------------------------------------------------------

function main()
    PreventUIRefresh(1)
    Undo_BeginBlock()

    local _, workflow = GetProjExtState(0, "ReaClassical", "Workflow")
    if workflow == "" then
        local modifier = "Ctrl"
        local system = GetOS()
        if string.find(system, "^OSX") or string.find(system, "^macOS") then
            modifier = "Cmd"
        end
        MB("Please create a ReaClassical project via " .. modifier
            .. "+N to use this function.", "ReaClassical Error", 0)
        return
    end

    local group_state = GetToggleCommandState(1156)
    if group_state ~= 1 then
        Main_OnCommand(1156, 0) -- Enable item grouping
    end

    if source_markers() == 2 then
        SetCursorContext(1, nil)
        Main_OnCommand(40310, 0) -- Set ripple per-track
        Main_OnCommand(40289, 0) -- Item: Unselect all items
        GoToMarker(0, 998, false)
        select_matching_folder()
        nudge_xfades_at_source_boundaries()
        Main_OnCommand(40625, 0)  -- Time Selection: Set start point
        GoToMarker(0, 999, false)
        Main_OnCommand(40626, 0)  -- Time Selection: Set end point
        Main_OnCommand(40718, 0)  -- Select all items on selected tracks in current time selection
        select_midpoint_peers()
        Main_OnCommand(41990, 0)  -- Toggle ripple per-track (off)
        adaptive_delete()
        Main_OnCommand(40630, 0)  -- Go to start of time selection
        Main_OnCommand(40020, 0)  -- Time Selection: Remove time selection and loop point selection
        DeleteProjectMarker(nil, 998, false)
        DeleteProjectMarker(nil, 999, false)
        Main_OnCommand(40289, 0) -- Item: Unselect all items
        Main_OnCommand(41990, 0) -- Toggle ripple per-track (on)
    else
        MB("Please use SOURCE-IN and SOURCE-OUT markers", "Delete Leaving Silence", 0)
    end
    Undo_EndBlock('Cut and Ripple', 0)
    PreventUIRefresh(-1)
    UpdateArrange()
    UpdateTimeline()
end

---------------------------------------------------------------------

function source_markers()
    local _, num_markers, num_regions = CountProjectMarkers(0)
    local exists = 0
    for i = 0, num_markers + num_regions - 1, 1 do
        local _, _, _, _, label, _ = EnumProjectMarkers(i)
        -- Accept both "PREFIX:SOURCE-IN/OUT" and bare "SOURCE-IN/OUT" forms
        local stripped = label:match(":(.+)$") or label
        if stripped == "SOURCE-IN" or stripped == "SOURCE-OUT" then
            exists = exists + 1
        end
    end
    return exists
end

---------------------------------------------------------------------

function find_folder_by_prefix(prefix)
    for i = 0, CountTracks(0) - 1 do
        local track = GetTrack(0, i)
        if GetMediaTrackInfo_Value(track, "I_FOLDERDEPTH") == 1 then
            local _, name = GetTrackName(track)
            if name:match("^(.-):" ) == prefix then return track end
        end
    end
    return nil
end

---------------------------------------------------------------------

function select_matching_folder()
    -- Vertical: derive folder from marker label prefix
    local _, nm, nr = CountProjectMarkers(0)
    for i = 0, nm + nr - 1 do
        local _, _, _, _, raw_label, id = EnumProjectMarkers2(0, i)
        if id == 998 or id == 999 then
            local prefix = raw_label:match("^(.-):")
            if prefix then
                local track = find_folder_by_prefix(prefix)
                if track then SetOnlyTrackSelected(track); return end
            end
            break
        end
    end
    -- Horizontal: only one folder exists, select it
    for i = 0, CountTracks(0) - 1 do
        local track = GetTrack(0, i)
        if GetMediaTrackInfo_Value(track, "I_FOLDERDEPTH") == 1 then
            SetOnlyTrackSelected(track); return
        end
    end
end

---------------------------------------------------------------------

function adaptive_delete()
    local sel_items = {}
    local item_count = count_selected_media_items()
    for i = 0, item_count - 1 do
        sel_items[#sel_items + 1] = get_selected_media_item_at(i)
    end

    local time_sel_start, time_sel_end = GetSet_LoopTimeRange(false, false, 0, 0, false)
    local items_in_time_sel = {}

    if time_sel_end - time_sel_start > 0 then
        for _, item in ipairs(sel_items) do
            local item_pos = GetMediaItemInfo_Value(item, "D_POSITION")
            local item_len = GetMediaItemInfo_Value(item, "D_LENGTH")
            local item_sel = GetMediaItemInfo_Value(item, "B_UISEL") == 1

            if item_sel then
                local intersectmatches = 0
                if time_sel_start >= item_pos and time_sel_end <= item_pos + item_len then
                    intersectmatches = intersectmatches + 1
                end
                if item_pos >= time_sel_start and item_pos + item_len <= time_sel_end then
                    intersectmatches = intersectmatches + 1
                end
                if time_sel_start <= item_pos + item_len and time_sel_end >= item_pos + item_len then
                    intersectmatches = intersectmatches + 1
                end
                if time_sel_end >= item_pos and time_sel_start < item_pos then
                    intersectmatches = intersectmatches + 1
                end

                if intersectmatches > 0 then
                    table.insert(items_in_time_sel, item)
                end
            end
        end
    end

    if #items_in_time_sel > 0 then
        Main_OnCommand(40312, 0) -- Delete items in time selection
    else
        Main_OnCommand(40006, 0) -- Delete items or time selection contents
    end
end

---------------------------------------------------------------------

function count_selected_media_items()
    local selected_count = 0
    local total_items = CountMediaItems(0)

    for i = 0, total_items - 1 do
        local item = GetMediaItem(0, i)
        if IsMediaItemSelected(item) then
            selected_count = selected_count + 1
        end
    end

    return selected_count
end

---------------------------------------------------------------------

function get_selected_media_item_at(index)
    local selected_count = 0
    local total_items = CountMediaItems(0)

    for i = 0, total_items - 1 do
        local item = GetMediaItem(0, i)
        if IsMediaItemSelected(item) then
            if selected_count == index then
                return item
            end
            selected_count = selected_count + 1
        end
    end

    return nil
end

---------------------------------------------------------------------

-- Returns all items on tracks folder_start..folder_end whose span contains
-- the midpoint of ref_item. This replaces I_GROUPID-based peer lookup.
function get_folder_items_at_midpoint(ref_item, folder_start, folder_end)
    local pos = GetMediaItemInfo_Value(ref_item, "D_POSITION")
    local len = GetMediaItemInfo_Value(ref_item, "D_LENGTH")
    local mid = pos + len * 0.5
    local tolerance = 0.0001
    local result = {}
    for t = folder_start, folder_end do
        local track = GetTrack(0, t)
        local n = CountTrackMediaItems(track)
        for i = 0, n - 1 do
            local item = GetTrackMediaItem(track, i)
            local ipos = GetMediaItemInfo_Value(item, "D_POSITION")
            local ilen = GetMediaItemInfo_Value(item, "D_LENGTH")
            if mid >= (ipos - tolerance) and mid <= (ipos + ilen + tolerance) then
                result[#result + 1] = item
            end
        end
    end
    return result
end

---------------------------------------------------------------------

function nudge_xfades_at_source_boundaries()
    local epsilon = 0.0001

    local source_in_pos, source_out_pos = nil, nil
    local _, num_markers, num_regions = CountProjectMarkers(0)
    for i = 0, num_markers + num_regions - 1 do
        local _, _, pos, _, _, id = EnumProjectMarkers2(0, i)
        if id == 998 then source_in_pos = pos end
        if id == 999 then source_out_pos = pos end
    end

    if not source_in_pos or not source_out_pos then return end

    local sel_track = GetSelectedTrack(0, 0)
    if not sel_track then return end
    local track_num = GetMediaTrackInfo_Value(sel_track, "IP_TRACKNUMBER") - 1
    local num_tracks = CountTracks(0)
    local folder_start, folder_end = nil, nil

    for t = track_num, num_tracks - 1 do
        local track = GetTrack(0, t)
        local depth = GetMediaTrackInfo_Value(track, "I_FOLDERDEPTH")
        if depth == 1 then
            folder_start = t
            folder_end = t
            local x = t + 1
            while x < num_tracks do
                local d = GetMediaTrackInfo_Value(GetTrack(0, x), "I_FOLDERDEPTH")
                folder_end = x
                if d < 0 then break end
                x = x + 1
            end
            break
        end
    end

    if not folder_start then return end

    local function find_overlap_at_pos(pos)
        local ref_track = GetTrack(0, folder_start)
        local n = CountTrackMediaItems(ref_track)
        for i = 0, n - 2 do
            local item_a = GetTrackMediaItem(ref_track, i)
            local item_b = GetTrackMediaItem(ref_track, i + 1)
            local a_start = GetMediaItemInfo_Value(item_a, "D_POSITION")
            local a_end   = a_start + GetMediaItemInfo_Value(item_a, "D_LENGTH")
            local b_start = GetMediaItemInfo_Value(item_b, "D_POSITION")
            if a_end > b_start then
                -- marker falls within the overlap region
                if pos > b_start and pos < a_end then
                    return item_a, item_b, a_end - b_start
                end
            end
        end
        return nil, nil, nil
    end

    local function move_xfade_boundaries(ref_a, ref_b, new_a_end, new_b_start)
        local peers_a = get_folder_items_at_midpoint(ref_a, folder_start, folder_end)
        local peers_b = get_folder_items_at_midpoint(ref_b, folder_start, folder_end)
        for _, item in ipairs(peers_a) do
            local ipos = GetMediaItemInfo_Value(item, "D_POSITION")
            SetMediaItemInfo_Value(item, "D_LENGTH", new_a_end - ipos)
        end
        for _, item in ipairs(peers_b) do
            local old_end = GetMediaItemInfo_Value(item, "D_POSITION")
                          + GetMediaItemInfo_Value(item, "D_LENGTH")
            SetMediaItemInfo_Value(item, "D_POSITION", new_b_start)
            SetMediaItemInfo_Value(item, "D_LENGTH",   old_end - new_b_start)
        end
    end

    -- Check and fix SOURCE-IN (nudge rightward into source region)
    local a, b, overlap_len_in = find_overlap_at_pos(source_in_pos)
    if a and b then
        local new_b_start = source_in_pos + epsilon
        local new_a_end   = new_b_start + overlap_len_in
        move_xfade_boundaries(a, b, new_a_end, new_b_start)
    end

    -- Check and fix SOURCE-OUT (nudge leftward into source region)
    local c, d, overlap_len_out = find_overlap_at_pos(source_out_pos)
    if c and d then
        local new_c_end   = source_out_pos - epsilon
        local new_d_start = new_c_end - overlap_len_out
        move_xfade_boundaries(c, d, new_c_end, new_d_start)
    end
end

---------------------------------------------------------------------

function select_midpoint_peers()
    local sel_track = GetSelectedTrack(0, 0)
    if not sel_track then return end
    local track_num = GetMediaTrackInfo_Value(sel_track, "IP_TRACKNUMBER") - 1
    local num_tracks = CountTracks(0)
    local folder_start, folder_end = nil, nil
    local start_search = track_num
    if GetMediaTrackInfo_Value(sel_track, "I_FOLDERDEPTH") ~= 1 then
        for t = track_num - 1, 0, -1 do
            local tt = GetTrack(0, t)
            if GetMediaTrackInfo_Value(tt, "I_FOLDERDEPTH") == 1 then
                start_search = t; break
            end
        end
    end
    for t = start_search, num_tracks - 1 do
        local tt = GetTrack(0, t)
        if GetMediaTrackInfo_Value(tt, "I_FOLDERDEPTH") == 1 then
            folder_start = t; folder_end = t
            local x = t + 1
            while x < num_tracks do
                local d = GetMediaTrackInfo_Value(GetTrack(0, x), "I_FOLDERDEPTH")
                folder_end = x
                if d < 0 then break end
                x = x + 1
            end
            break
        end
    end
    if not folder_start then return end
    local seed_items = {}
    local num_sel = CountSelectedMediaItems(0)
    for i = 0, num_sel - 1 do
        seed_items[#seed_items + 1] = GetSelectedMediaItem(0, i)
    end
    for _, ref_item in ipairs(seed_items) do
        local ref_pos = GetMediaItemInfo_Value(ref_item, "D_POSITION")
        local ref_len = GetMediaItemInfo_Value(ref_item, "D_LENGTH")
        local mid = ref_pos + ref_len * 0.5
        local tolerance = 0.0001
        for t = folder_start, folder_end do
            local track = GetTrack(0, t)
            local n = CountTrackMediaItems(track)
            for i = 0, n - 1 do
                local item = GetTrackMediaItem(track, i)
                local ipos = GetMediaItemInfo_Value(item, "D_POSITION")
                local ilen = GetMediaItemInfo_Value(item, "D_LENGTH")
                if mid >= (ipos - tolerance) and mid <= (ipos + ilen + tolerance) then
                    SetMediaItemSelected(item, true)
                end
            end
        end
    end
end

---------------------------------------------------------------------

main()