--[[
@noindex

This file is a part of "ReaClassical" package.
See "ReaClassical.lua" for more information.

Copyright (C) 2022–2026 chmaha

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
]]

-- luacheck: ignore 113

for key in pairs(reaper) do _G[key] = reaper[key] end

local script_path = debug.getinfo(1, "S").source:match("@(.+[\\/])")
package.path = package.path .. ";" .. script_path .. "?.lua;" .. script_path .. "lib/?.lua;"
local say = require("ReaClassical_Announce")
local xfu = require("ReaClassical_XFM_Utils")
local rank_info = require("ReaClassical_Rank_Info")
local active_folder = require("ReaClassical_Active_Folder")
local automation_ownership = require("ReaClassical_Automation_Ownership")

local main, move_to_next_item, get_selected_media_item_at, announce_current_item
local navigate_xfade, sync_playhead, sync_active_folder
local get_envelope_stops, get_selected_stop_index, select_only_stop
local announce_envelope_stop, move_envelope, clear_all_envelope_selections

function sync_playhead()
    if GetPlayState() & 1 == 1 then
        SetEditCurPos(GetCursorPosition(), false, true)
    end
end

function sync_active_folder()
    local item = get_selected_media_item_at(0)
    if not item then return end
    local track = GetMediaItem_Track(item)
    local folder = xfu.is_folder_track(track) and track or xfu.get_parent_folder(track)
    if not folder then return end

    if GetMediaTrackInfo_Value(folder, "B_MUTE") == 1 then
        active_folder.set_active(folder)
    end
end

function get_envelope_stops(env)
    local stops = {}

    local ai_count = CountAutomationItems(env)
    for i = 0, ai_count - 1 do
        local pos = GetSetAutomationItemInfo(env, i, "D_POSITION", 0, false)
        stops[#stops + 1] = { time = pos, kind = "ai", idx = i }
    end

    local pt_count = CountEnvelopePointsEx(env, -1)
    for i = 0, pt_count - 1 do
        local ok, time, value = GetEnvelopePointEx(env, -1, i)
        if ok then
            stops[#stops + 1] = { time = time, kind = "point", idx = i, value = value }
        end
    end

    table.sort(stops, function(a, b) return a.time < b.time end)
    return stops
end

function get_selected_stop_index(env, stops)
    for i, s in ipairs(stops) do
        if s.kind == "point" then
            local ok, _, _, _, _, selected = GetEnvelopePointEx(env, -1, s.idx)
            if ok and selected then return i end
        else
            local selected = GetSetAutomationItemInfo(env, s.idx, "D_UISEL", 0, false)
            if selected and selected > 0 then return i end
        end
    end
    return nil
end

function clear_all_envelope_selections()
    local function clear_envelope(env)
        local pt_count = CountEnvelopePointsEx(env, -1)
        for i = 0, pt_count - 1 do
            SetEnvelopePointEx(env, -1, i, nil, nil, nil, nil, false, true)
        end
        Envelope_SortPointsEx(env, -1)

        local ai_count = CountAutomationItems(env)
        for i = 0, ai_count - 1 do
            GetSetAutomationItemInfo(env, i, "D_UISEL", 0, true)
        end
    end

    local master = GetMasterTrack(0)
    if master then
        for e = 0, CountTrackEnvelopes(master) - 1 do
            clear_envelope(GetTrackEnvelope(master, e))
        end
    end

    for t = 0, CountTracks(0) - 1 do
        local track = GetTrack(0, t)
        for e = 0, CountTrackEnvelopes(track) - 1 do
            clear_envelope(GetTrackEnvelope(track, e))
        end
    end

    SelectAllMediaItems(0, false)
end

function select_only_stop(env, stops, target_index)
    clear_all_envelope_selections()
    local target = stops[target_index]
    if target.kind == "point" then
        SetEnvelopePointEx(env, -1, target.idx, nil, nil, nil, nil, true, true)
        Envelope_SortPointsEx(env, -1)
    else
        GetSetAutomationItemInfo(env, target.idx, "D_UISEL", 1, true)
    end
end

function announce_envelope_stop(env, stops, target_index, boundary_word)
    local target = stops[target_index]
    local _, env_name = GetEnvelopeName(env, "")
    local pos_str = format_timestr_pos(target.time, "", -1)
    local kind_word = (target.kind == "ai") and "automation item" or "point"
    local prefix = boundary_word and (boundary_word .. " ") or ""

    local ordinal, total = 0, 0
    for i, s in ipairs(stops) do
        if s.kind == target.kind then
            total = total + 1
            if i == target_index then ordinal = total end
        end
    end

    if target.kind == "ai" then
        say(string.format("%s%s %s %d of %d at %s", prefix, env_name, kind_word, ordinal, total, pos_str))
    else
        say(string.format("%s%s %s %d of %d at %s, value %.2f",
            prefix, env_name, kind_word, ordinal, total, pos_str, target.value))
    end
end

function move_envelope(env, direction)
    local stops = get_envelope_stops(env)
    if #stops == 0 then
        say("No envelope points")
        return
    end

    local cur_idx = get_selected_stop_index(env, stops)
    local ref_time = cur_idx and stops[cur_idx].time or GetCursorPosition()
    local inclusive = (cur_idx == nil)
    local eps = 0.0000001

    local target_index
    if direction > 0 then
        for i, s in ipairs(stops) do
            if (inclusive and s.time >= ref_time - eps) or (not inclusive and s.time > ref_time + eps) then
                target_index = i
                break
            end
        end
    else
        for i = #stops, 1, -1 do
            if (inclusive and stops[i].time <= ref_time + eps)
                or (not inclusive and stops[i].time < ref_time - eps) then
                target_index = i
                break
            end
        end
    end

    if not target_index then
        target_index = (direction > 0) and #stops or 1
        select_only_stop(env, stops, target_index)
        SetEditCurPos(stops[target_index].time, true, false)
        announce_envelope_stop(env, stops, target_index, (direction > 0) and "Last" or "First")
        return
    end

    select_only_stop(env, stops, target_index)
    SetEditCurPos(stops[target_index].time, true, false)
    announce_envelope_stop(env, stops, target_index)
end

function announce_current_item()
    local item = get_selected_media_item_at(0)
    if not item then return end
    local take = GetActiveTake(item)
    local name = ""
    if take then
        _, name = GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
    end
    if name == "" then
        say("(unnamed)")
        return
    end
    local rank_suffix = rank_info.rank_announce_suffix(item)
    name = rank_info.strip_rank_prefix(name)
    if name == "" then
        say("(unnamed)" .. rank_suffix)
        return
    end
    local prefix, take_num = name:match("^(.+)_T(%d+)$")
    if take_num then
        say(prefix .. " take " .. tonumber(take_num) .. rank_suffix)
        return
    end
    local only_num = name:match("^(%d+)$")
    if only_num then
        say("Take " .. tonumber(only_num) .. rank_suffix)
        return
    end
    say(name .. rank_suffix)
end

function move_to_next_item()
    automation_ownership.deselect_all_automation_items()
    local item = get_selected_media_item_at(0)
    if not item then
        Main_OnCommand(40417, 0)
        Main_OnCommand(40034, 0)
        return
    end

    local item_pos = GetMediaItemInfo_Value(item, "D_POSITION")
    local item_len = GetMediaItemInfo_Value(item, "D_LENGTH")
    local item_end = item_pos + item_len
    local cursor_pos = GetCursorPosition()
    local eps = 0.00001

    if cursor_pos < item_end - eps then
        Main_OnCommand(40417, 0)
        Main_OnCommand(40034, 0)
        return
    end

    local track = GetMediaItem_Track(item)
    local item_count = CountTrackMediaItems(track)
    local item_idx = nil
    for i = 0, item_count - 1 do
        if GetTrackMediaItem(track, i) == item then
            item_idx = i
            break
        end
    end

    if item_idx == nil or item_idx >= item_count - 1 then
        Main_OnCommand(40417, 0)
        Main_OnCommand(40034, 0)
        return
    end

    local next_item = GetTrackMediaItem(track, item_idx + 1)
    local next_pos = GetMediaItemInfo_Value(next_item, "D_POSITION")
    Main_OnCommand(40289, 0)
    SetMediaItemSelected(next_item, true)
    SetEditCurPos(next_pos, true, false)
    Main_OnCommand(40034, 0)
end

function navigate_xfade(direction)
    local idx    = tonumber(GetExtState("ReaClassical", "XFadeFolderIdx"))
    local center = tonumber(GetExtState("ReaClassical", "XFadeCenter"))
    if not idx or not center then say("No crossfade context"); return end

    local folder_track = GetTrack(0, idx)
    if not folder_track then say("No crossfade context"); return end

    local xfades = xfu.find_crossfades(folder_track)
    if #xfades == 0 then say("No crossfades found"); return end

    local cur_i = 1
    local best_dist
    for i, xf in ipairs(xfades) do
        local d = math.abs(xf.center - center)
        if not best_dist or d < best_dist then
            cur_i = i; best_dist = d
        end
    end

    local next_i = cur_i + direction
    local boundary
    if next_i < 1 then
        next_i = 1; boundary = "First"
    elseif next_i > #xfades then
        next_i = #xfades; boundary = "Last"
    end

    local target = xfades[next_i]
    xfu.set_xfade_state(folder_track, target.center)
    xfu.set_selection("both")

    local mid1   = target.pos1 + target.len1 * 0.5
    local mid2   = target.pos2 + GetMediaItemInfo_Value(target.item2, "D_LENGTH") * 0.5
    local group1 = xfu.get_items_at_midpoint(folder_track, mid1)
    local group2 = xfu.get_items_at_midpoint(folder_track, mid2)
    local all    = {}
    for _, it in ipairs(group1) do all[#all + 1] = it end
    for _, it in ipairs(group2) do all[#all + 1] = it end
    xfu.select_items(all)
    SetEditCurPos(target.center, true, false)

    local prefix = boundary and (boundary .. " crossfade") or
        ("Crossfade " .. next_i .. " of " .. #xfades)
    say(prefix)
end

function main()
    local _, workflow = GetProjExtState(0, "ReaClassical", "Workflow")
    if workflow == "" then
        local modifier = "Ctrl"
        local system = GetOS()
        if string.find(system, "^OSX") or string.find(system, "^macOS") then
            modifier = "Cmd"
        end
        MB("Please create a ReaClassical project via " .. modifier
            .. "+N to use this function.", "ReaClassical Error", 0)
        return
    end

    if xfu.is_xfade_mode() then
        navigate_xfade(1)
        sync_playhead()
        UpdateArrange()
        UpdateTimeline()
        return
    end

    local env = GetSelectedEnvelope(0)
    if env then
        move_envelope(env, 1)
        sync_playhead()
        UpdateArrange()
        UpdateTimeline()
        return
    end

    move_to_next_item()
    sync_active_folder()
    sync_playhead()

    UpdateArrange()
    UpdateTimeline()
    announce_current_item()
end

function get_selected_media_item_at(index)
    local selected_count = 0
    local total_items = CountMediaItems(0)

    for i = 0, total_items - 1 do
        local item = GetMediaItem(0, i)
        if IsMediaItemSelected(item) then
            if selected_count == index then
                return item
            end
            selected_count = selected_count + 1
        end
    end

    return nil
end

main()
