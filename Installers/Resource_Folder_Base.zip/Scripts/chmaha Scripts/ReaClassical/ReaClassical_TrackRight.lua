--[[
@noindex

This file is a part of "ReaClassical" package.
See "ReaClassical.lua" for more information.

Copyright (C) 2022–2026 chmaha

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
]]

-- luacheck: ignore 113

for key in pairs(reaper) do _G[key] = reaper[key] end

local main, takename_check, check_position, get_track_info
local select_CD_track_items, next_track, switch_highlight
local is_item_start_crossfaded, pos_check, get_selected_media_item_at
local is_folder_track, is_in_child_track, get_parent_folder

---------------------------------------------------------------------

function main()
    Undo_BeginBlock()
    local _, workflow = GetProjExtState(0, "ReaClassical", "Workflow")
    if workflow == "" then
        local modifier = "Ctrl"
        local system = GetOS()
        if string.find(system, "^OSX") or string.find(system, "^macOS") then
            modifier = "Cmd"
        end
        MB("Please create a ReaClassical project via " .. modifier
            .. "+N to use this function.", "ReaClassical Error", 0)
        return
    end
    local take_name, selected_item = takename_check()
    if take_name == -1 or take_name == "" then
        MB('Please select an item that starts a CD track', "Select CD track start", 0)
        return
    end

    local selected_track = GetMediaItemTrack(selected_item)

    -- Check if selected item is in a child track
    if is_in_child_track(selected_item) or not is_folder_track(selected_track) then
        MB('Please select an item on a parent folder track.', "Select CD track start", 0)
        return
    end

    local item_start_crossfaded, folder_track, num_of_items, item_number, count = pos_check(selected_item)

    if item_start_crossfaded then
        Main_OnCommand(40769, 0) -- unselect all
        SetMediaItemSelected(selected_item, true)
        MB('The selected track start is crossfaded' ..
            ' and therefore cannot be moved', "Select CD track start", 0)
        return
    end

    if item_number + count == num_of_items - 1 then
        Main_OnCommand(40769, 0) -- unselect all
        SetMediaItemSelected(selected_item, true)
        MB('The selected track is already in last position', "Select CD track start", 0)
        return
    end

    PreventUIRefresh(1)

    next_track(folder_track, item_number, count)

    local ReaClassical_TrackLeft = NamedCommandLookup("_RS18fe066cb8806e30b0371fc30a79c67ce2b807f1")
    Main_OnCommand(ReaClassical_TrackLeft, 0)

    switch_highlight(selected_item)
    SetOnlyTrackSelected(folder_track)
    PreventUIRefresh(-1)
    Undo_EndBlock("Move Track Right", -1)
end

---------------------------------------------------------------------

function is_folder_track(track)
    if not track then return false end
    local folder_depth = GetMediaTrackInfo_Value(track, "I_FOLDERDEPTH")
    return folder_depth == 1
end

---------------------------------------------------------------------

function is_in_child_track(item)
    if not item then return false end
    local track = GetMediaItemTrack(item)
    if not track then return false end

    -- Check if this track is a folder parent
    if is_folder_track(track) then
        return false
    end

    -- Check if this track has a parent folder
    local parent = get_parent_folder(track)
    return parent ~= nil
end

---------------------------------------------------------------------

function get_parent_folder(track)
    -- Returns the parent folder track, or nil if track is not in a folder
    if not track then return nil end

    local track_idx = GetMediaTrackInfo_Value(track, "IP_TRACKNUMBER") - 1

    -- Walk backwards to find parent folder
    for i = track_idx - 1, 0, -1 do
        local t = GetTrack(0, i)
        if not t then break end

        local depth = GetMediaTrackInfo_Value(t, "I_FOLDERDEPTH")
        if depth == 1 then
            return t
        end
    end

    return nil
end

---------------------------------------------------------------------

function takename_check()
    local item = get_selected_media_item_at(0)
    if item then
        local take = GetActiveTake(item)
        local _, take_name = GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
        return take_name, item
    else
        return -1
    end
end

---------------------------------------------------------------------

function check_position(item)
    local item_number = GetMediaItemInfo_Value(item, "IP_ITEMNUMBER")
    return item_number
end

---------------------------------------------------------------------

function get_track_info(item)
    local folder_track = GetMediaItemTrack(item)
    return folder_track, GetTrackNumMediaItems(folder_track)
end

---------------------------------------------------------------------

function select_CD_track_items(item_number, num_of_items, track)
    local count = 0
    if item_number ~= num_of_items - 1 then
        for i = item_number + 1, num_of_items - 1, 1 do
            local item = GetTrackMediaItem(track, i)
            local prev_item = GetTrackMediaItem(track, i - 1)
            local take = GetActiveTake(item)
            local _, take_name = GetSetMediaItemTakeInfo_String(take, "P_NAME", "", false)
            local prev_pos = GetMediaItemInfo_Value(prev_item, "D_POSITION")
            local prev_len = GetMediaItemInfo_Value(prev_item, "D_LENGTH")
            local prev_end = prev_pos + prev_len
            local next_pos = GetMediaItemInfo_Value(item, "D_POSITION")
            if take_name == "" or next_pos < prev_end then
                SetMediaItemSelected(item, true)
                count = count + 1
            else
                break
            end
        end
    end
    return count
end

---------------------------------------------------------------------

function next_track(folder_track, item_number, count)
    Main_OnCommand(40769, 0) -- unselect all
    local next_track_item = GetTrackMediaItem(folder_track, item_number + count + 1)
    SetMediaItemSelected(next_track_item, true)
end

---------------------------------------------------------------------

function switch_highlight(item)
    Main_OnCommand(40769, 0) -- unselect all

    SetMediaItemSelected(item, true)
end

---------------------------------------------------------------------

function pos_check(selected_item)
    local folder_track, num_of_items = get_track_info(selected_item)
    local item_number = check_position(selected_item)
    local item_start_crossfaded = is_item_start_crossfaded(folder_track, item_number)
    local count = select_CD_track_items(item_number, num_of_items, folder_track)
    Main_OnCommand(40769, 0) -- unselect all
    SetMediaItemSelected(selected_item, true)
    return item_start_crossfaded, folder_track, num_of_items, item_number, count
end

---------------------------------------------------------------------

function is_item_start_crossfaded(folder_track, item_number)
    local item = GetTrackMediaItem(folder_track, item_number)
    local next_pos = GetMediaItemInfo_Value(item, "D_POSITION")
    local prev_item = GetTrackMediaItem(folder_track, item_number - 1)
    if prev_item then
        local prev_pos = GetMediaItemInfo_Value(prev_item, "D_POSITION")
        local prev_len = GetMediaItemInfo_Value(prev_item, "D_LENGTH")
        local prev_end = prev_pos + prev_len
        if prev_end > next_pos then
            return true
        end
    end
    return false
end

---------------------------------------------------------------------

function get_selected_media_item_at(index)
    local selected_count = 0
    local total_items = CountMediaItems(0)

    for i = 0, total_items - 1 do
        local item = GetMediaItem(0, i)
        if IsMediaItemSelected(item) then
            if selected_count == index then
                return item
            end
            selected_count = selected_count + 1
        end
    end

    return nil
end

---------------------------------------------------------------------

main()
