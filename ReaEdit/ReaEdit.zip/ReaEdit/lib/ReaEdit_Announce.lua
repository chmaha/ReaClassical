--[[
@noindex

This file is a part of "ReaEdit" package.
See "ReaEdit.lua" for more information.

Copyright (C) 2022–2026 chmaha

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
]]

-- luacheck: ignore 113

for key in pairs(reaper) do _G[key] = reaper[key] end

local _, debug_announce = GetProjExtState(0, "ReaEdit", "DebugAnnounce")

local function say(msg, no_store)
    msg = tostring(msg)
    if not no_store then
        SetProjExtState(0, "ReaEdit", "LastAnnouncement", msg)
    end
    if APIExists("osara_outputMessage") then
        osara_outputMessage(msg)
    elseif debug_announce == "on" then
        ShowConsoleMsg(msg .. "\n")
    end
end

return say
