--[[
@noindex

This file is a part of "ReaEdit" package.
See "ReaEdit.lua" for more information.

Copyright (C) 2022–2026 chmaha

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
]]

-- Only in the manual-download zip (not in the ReaPack package: ReaPack registers the actions itself).
-- Run this once from REAPER's Action List (Actions > Show action list > New action > Load ReaScript...) after
-- unzipping ReaEdit: it adds every ReaEdit_*.lua script in this folder to the Action List. Running it again is
-- harmless.

local folder = debug.getinfo(1, "S").source:match("@(.+[\\/])")
if not folder then
    reaper.MB("Could not work out where this script is.", "ReaEdit", 0)
    return
end

local names = {}
local i = 0
while true do
    local file = reaper.EnumerateFiles(folder, i)
    if not file then break end
    if file:match("^ReaEdit_.*%.lua$") then names[#names + 1] = file end
    i = i + 1
end
table.sort(names)

if #names == 0 then
    reaper.MB("No ReaEdit_*.lua scripts were found next to this one.\n\n"
        .. "Please unzip the whole ReaEdit folder and run this script from inside it.", "ReaEdit", 0)
    return
end

local added = 0
for n, file in ipairs(names) do
    -- Section 0 is the Main action list. Only the last call commits the changes to the keymap file.
    if reaper.AddRemoveReaScript(true, 0, folder .. file, n == #names) ~= 0 then added = added + 1 end
end

reaper.MB(("Registered %d of %d ReaEdit actions.\n\n"
    .. "Open the Action List and search for \"ReaEdit\" to find them. ReaEdit does not assign keyboard "
    .. "shortcuts, so bind the ones you use most."):format(added, #names), "ReaEdit", 0)
