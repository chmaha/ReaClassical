--[[
@noindex

This file is a part of "ReaEdit" package.
See "ReaEdit.lua" for more information.

Copyright (C) 2022–2026 chmaha

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
]]

-- luacheck: ignore 113

for key in pairs(reaper) do _G[key] = reaper[key] end

local script_path = debug.getinfo(1, "S").source:match("@(.+[\\/])")
package.path = package.path .. ";" .. script_path .. "?.lua;" .. script_path .. "../lib/?.lua;"
local say = require("ReaEdit_Announce")
local xfu = require("ReaEdit_XFM_Utils")

local function main()
    if not xfu.is_xfade_mode() then return end

    local ctx = xfu.get_xfade_context()
    if not ctx then say("No crossfade context"); return end
    xfu.ensure_xfade_snapshot(ctx)

    local amt    = xfu.nudge_amount()
    local old_fo = GetMediaItemInfo_Value(ctx.item1, "D_FADEOUTLEN")

    local ok, err = xfu.check_item1_headroom(ctx, amt)
    if not ok then say(err); return end

    Undo_BeginBlock()
    PreventUIRefresh(1)

    for _, item in ipairs(ctx.group1) do
        local fo = GetMediaItemInfo_Value(item, "D_FADEOUTLEN")
        SetMediaItemInfo_Value(item, "D_FADEOUTLEN",      fo + amt)
        SetMediaItemInfo_Value(item, "D_FADEOUTLEN_AUTO", fo + amt)
    end

    for _, item in ipairs(ctx.group2) do
        local p  = GetMediaItemInfo_Value(item, "D_POSITION")
        local s  = xfu.get_item_soffs(item)
        local l  = GetMediaItemInfo_Value(item, "D_LENGTH")
        local fi = GetMediaItemInfo_Value(item, "D_FADEINLEN")
        SetMediaItemInfo_Value(item, "D_POSITION",       math.max(0, p - amt))
        xfu.set_item_soffs(item,                         math.max(0, s - amt))
        SetMediaItemInfo_Value(item, "D_LENGTH",         l + amt)
        SetMediaItemInfo_Value(item, "D_FADEINLEN",      fi + amt)
        SetMediaItemInfo_Value(item, "D_FADEINLEN_AUTO", fi + amt)
    end

    UpdateArrange()
    UpdateTimeline()
    PreventUIRefresh(-1)
    Undo_EndBlock("XFM Widen", -1)
    say("Crossfade widened to " .. math.floor((old_fo + amt) * 1000 + 0.5)  .. " milliseconds")
end

main()
