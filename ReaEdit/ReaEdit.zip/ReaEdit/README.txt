ReaEdit 1.1 - source-destination editing tools for REAPER
================================================================

Free, no license key. Recommended: install through ReaPack instead of this zip,
which registers the actions for you and keeps ReaEdit up to date:
https://reaclassical.com/reaedit/

Installing from this zip
------------------------
1. Unzip this folder (ReaEdit) into REAPER's Scripts folder
   (REAPER: Options > Show REAPER resource path in explorer/finder > Scripts).
   Keep all the files together in one folder.
2. In REAPER open the Action List (Actions > Show action list...),
   choose New action > Load ReaScript..., and select
   "Register ReaEdit actions.lua" from the unzipped folder.
   Run it once. It adds every ReaEdit action to the Action List.
3. Search the Action List for "ReaEdit" and bind the shortcuts you want.
   (The keyboard crossfade mode's actions are in the XFM folder. They are not added to the Action List
   here; setting up the crossfade mode keys adds them. See the manual's Crossfade Mode chapter.)

Updating: download the newest zip and unzip it over the old folder (say yes to
overwrite), then run "Register ReaEdit actions.lua" again.

Removing: delete the ReaEdit folder, then remove the leftover ReaEdit entries
from the Action List.
